//
//  Administrator.h
//  
//
//  Created by Abhiram Santhosh on 3/30/19.
//

#ifndef Administrator_h
#define Administrator_h

#include <stdio.h>

#endif /* Administrator_h */
